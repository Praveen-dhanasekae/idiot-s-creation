

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;

/**
 * Servlet implementation class mailgen
 */
@WebServlet("/mailgen")
public class mailgen extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
   		
   	    
        String to = (String) request.getSession(false).getAttribute("email");
        String from = "praveenavantgrade@gmail.com" ;
        String host = "localhost";
        Properties properties = System.getProperties();
        properties.setProperty("mail.user", "praveenavantgrade@gmail.com");
        properties.setProperty("mail.password", "Avantgrade7799");
        properties.setProperty("mail.smtp.host", host);
        Random rand = new Random();
        int random = rand.nextInt(10000);
        request.getSession(false).setAttribute("OTP",random);
        Session session = Session.getDefaultInstance(properties);
        

        try {
           MimeMessage message = new MimeMessage(session);
           message.setFrom(new InternetAddress(from));
           message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
           message.setSubject("OTP initiated for the transcation!");
           message.setText("This is the otp "+ random );
           Transport.send(message);
           
        } catch (MessagingException mex) {
           mex.printStackTrace();
        }
		
	}


}
