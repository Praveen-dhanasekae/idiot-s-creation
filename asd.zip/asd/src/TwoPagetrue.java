

import java.io.IOException;
import java.lang.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TwoPagetrue
 */
@WebServlet("/TwoPagetrue")
public class TwoPagetrue extends HttpServlet 
 {
	private static final long serialVersionUID = 1L;
       
   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
   {
	   String type = request.getParameter("type");
	   boolean accountinfo = false;
	   // enter lines to connect with db and evaluate the cash flow
	   //check if type is correct or not 
	   if(accountinfo == true )
	   {
	   if(type == "Savings")
	   {
        //get cash left from db
		 //get account number also to display  
		   Integer accountno = 123456789 ;
		  Integer CashLeft=100;
		  RequestDispatcher myDispatch = request.getRequestDispatcher("/Thirdpage.jsp");
	        request.setAttribute("cash", CashLeft);
	        request.setAttribute("accno",accountno);
	        myDispatch.forward(request, response);
		  
		    
	   }
	   
	   }
	   else
	   {
		   RequestDispatcher myDispatch = request.getRequestDispatcher("/ThirdpageF.jsp");
	        myDispatch.forward(request, response);
	   }
   }

  }


