
import java.io.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class login
 */
@WebServlet("/login")
public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		  final String username = request.getParameter("username");
	        String password = request.getParameter("password");
	       String captcha= request.getParameter("captcha");
	       System.out.println("Inside DoPOst");
           if((username.equals("john"))&&(password.equals("john"))||(captcha.equals("QDfsde")))
            {
	        
	         System.out.println("Inside If");
	        RequestDispatcher myDispatch = request.getRequestDispatcher("/logSfo.jsp");
	        request.setAttribute("name", "john");
	        myDispatch.forward(request, response);
	      //getServletContext().getRequestDispatcher("logSf.html").forward(request, response);
	        
            }
            else
            {
            	 PrintWriter writer = response.getWriter();
    	         
     	        // build HTML code
     	        String htmlRespone = "<html>";
     	        htmlRespone += "<h2>Hello " + username + "<br/>";      
     	        htmlRespone += "Your record was not found ,Please enter the correct credentials</h2>";    
     	        htmlRespone += "</html>";
     	         
     	        // return response
     	        writer.println(htmlRespone);
            }
	}

}
