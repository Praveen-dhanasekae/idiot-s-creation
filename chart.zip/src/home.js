import React,{Component} from 'react';
import './App';
import img from './sar1.jpg';
export default class home extends Component{
    render(){
        return(
            <div>
            <header style={{height:'50px', textAlign:'center'}}>
                    <h1>Insurance</h1>
            </header>
           <img style={{width:'100%', height:'500px'}} alt="sar" src={img}/>
           
        </div>
        )
    }
}
    