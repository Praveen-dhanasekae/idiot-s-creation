
/**
 *
 * Annotation support for AOP pointcuts.
 *
 */
package org.springframework.aop.support.annotation;

