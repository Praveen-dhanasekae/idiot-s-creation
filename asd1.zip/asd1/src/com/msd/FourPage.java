package com.msd;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.Statement;

/**
 * Servlet implementation class FourPage
 */
@WebServlet("/FourPage")
public class FourPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    int Toacc= Integer.parseInt(request.getParameter("toacc"));
	    int Fromacc=Integer.parseInt( (String) request.getSession(false).getAttribute("accType"));
	   int cashPresent =Integer.parseInt((String) request.getSession(false).getAttribute("accAmt"));
	//request.getSession(false).getAttribute("accName") ;
		int amtDeduct = Integer.parseInt(request.getParameter("amt"));
		String atype= request.getParameter("atype") ;
		Integer OTP = (Integer)request.getSession(false).getAttribute("OTP");
		int otp = Integer.parseInt(request.getParameter("OTPP"));
		if(OTP ==otp)
		{
		    if(amtDeduct<cashPresent)
		  {
			 try
		       {   System.out.println("Inside DoPOst2");
		       Integer NewcashA2 = null,UpdateCash = null;
		            Class.forName("com.mysql.jdbc.Driver").newInstance();
		           Connection myConn=DriverManager.getConnection("jdbc:mysql://localhost:3306/Bank","root","");
		           Statement stmt= (Statement) myConn.createStatement();
		           ResultSet rs=stmt.executeQuery("select * from maintable where "+atype+" ="+Toacc);
		          while(rs.next())
		          {  NewcashA2= Integer.parseInt(rs.getString(atype+"_Amt"));
		             NewcashA2+=amtDeduct;
		             UpdateCash= cashPresent-amtDeduct;
		             
		           }
		          stmt.executeUpdate("Update maintable set "+atype+"_Amt="+NewcashA2+"  where "+atype+" ="+Toacc);
		          stmt.executeUpdate("Update maintable set "+request.getSession(false).getAttribute("accName") +"_Amt="+UpdateCash+"  where "+request.getSession(false).getAttribute("accName")+" ="+Fromacc);
		          if(request.getSession(false).getAttribute("accName").equals("SB_Acc"))
		          { if(UpdateCash>=500)  
		            { rs= stmt.executeQuery("select "+request.getSession(false).getAttribute("accName")+" from table2 where Aadhar ="+request.getSession(false).getAttribute("Aadhar"));
		            rs.next(); 
		            int ne=Integer.parseInt( (String) rs.getString(1));
		            ne+=1;System.out.println(ne);
		               stmt.executeUpdate("Update table2 set "+request.getSession(false).getAttribute("accName") +"="+ ne +"  where "+request.getSession(false).getAttribute("accName")+" ="+Fromacc);
		            } 		
		          if(UpdateCash<500)  
		            { rs= stmt.executeQuery("select "+request.getSession(false).getAttribute("accName")+"_low from table2 where Aadhar ="+request.getSession(false).getAttribute("Aadhar"));
		            rs.next(); 
		            int ne=Integer.parseInt( (String) rs.getString(1));
		            ne+=1;System.out.println(ne);
		               stmt.executeUpdate("Update table2 set "+request.getSession(false).getAttribute("accName") +"_low ="+ ne +"  where Aadhar ="+request.getSession(false).getAttribute("Aadhar"));

		            }
		          
		           }
		          if(request.getSession(false).getAttribute("accName").equals("CB_Acc"))
		          { if(UpdateCash>=2000)  
		            { rs= stmt.executeQuery("select "+request.getSession(false).getAttribute("accName")+" from table2 where Aadhar ="+request.getSession(false).getAttribute("Aadhar"));
		            rs.next();  
		            int ne=Integer.parseInt( (String) rs.getString(1));
		            ne+=1;System.out.println(ne);
		               stmt.executeUpdate("Update table2 set "+request.getSession(false).getAttribute("accName") +"="+ ne +"  where Aadhar ="+request.getSession(false).getAttribute("Aadhar"));
		            } 		
		          if(UpdateCash<2000)  
		            { rs= stmt.executeQuery("select "+request.getSession(false).getAttribute("accName")+"_low from table2 where Aadhar ="+request.getSession(false).getAttribute("Aadhar"));
		            rs.next();  
		            int ne=Integer.parseInt( (String) rs.getString(1));
		            ne+=1;System.out.println(ne);
		               stmt.executeUpdate("Update table2 set "+request.getSession(false).getAttribute("accName") +"_low ="+ ne +"  where Aadhar ="+request.getSession(false).getAttribute("Aadhar"));
		            } 		
		          
		          
		           }
		          // Runtime.getRuntime().exec("python pyScript.py");
		          RequestDispatcher myDispatch = request.getRequestDispatcher("/OTPSuccess.jsp");
		   	        myDispatch.forward(request, response);
		       }
		       catch(Exception e)
		       {
		           System.out.println(e);
		       }
			 
		    

			
		   }
		  else
		  {
			response.sendRedirect("TransDeclined.jsp");
		  }
	}
	
	else 
	{
		response.sendRedirect("OTPFailed.jsp");

	}
	
	}

}
