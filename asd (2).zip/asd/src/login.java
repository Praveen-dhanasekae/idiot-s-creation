
import java.io.*;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
/**
 * Servlet implementation class login
 */

import com.mysql.jdbc.Statement;
@WebServlet("/login")
public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{      System.out.println("Inside DoPOst 1");
		  final String username = request.getParameter("username");
	        String password = request.getParameter("password");
	       String captcha= request.getParameter("captcha");
	       request.getSession(true).setAttribute("user",username);
	       try
	       {   System.out.println("Inside DoPOst2");
	           //loading the jdbc driver
	            Class.forName("com.mysql.jdbc.Driver").newInstance();
	           //get a connection to database
	           Connection myConn=DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","");
	           //create a statement
	           Statement stmt= (Statement) myConn.createStatement();
	           //execute sql query
	           ResultSet rs=stmt.executeQuery("select * from maintable where username ="+username);
	           //process the result
	          //  String sno = null,Aadhar = null,u = null,pass = null,email = null,SB_AccNo = null,SB_Acc_Amt = null, Loan_AccNo = null,Loan_Acc_Amt = null, CB_AccNo = null,CB_Acc_Amt = null,FD_AccNo = null,FD_Acc_Amt = null;
	        	   request.getSession(false).setAttribute("sno",rs.getString(1));
	        	   request.getSession(false).setAttribute("Aadhar" ,rs.getString(2));
	        	   request.getSession(false).setAttribute("u",rs.getString(3));
	        	   request.getSession(false).setAttribute("pass" ,rs.getString(4));
	        	   request.getSession(false).setAttribute("email",rs.getString(5));
	        	   request.getSession(false).setAttribute("SB_AccNo" ,rs.getString(6));
	        	   request.getSession(false).setAttribute("SB_Acc_Amt",rs.getString(7));
	        	   request.getSession(false).setAttribute("Loan_AccNo" ,rs.getString(8));
	        	   request.getSession(false).setAttribute("Loan_Acc_Amt" ,rs.getString(9));
	        	   request.getSession(false).setAttribute("CB_AccNo",rs.getString(10));
	        	   request.getSession(false).setAttribute("CB_Acc_Amt",rs.getString(11));
	        	   request.getSession(false).setAttribute("FD_AccNo",rs.getString(12));
	        	   request.getSession(false).setAttribute("FD_Acc_Amt",rs.getString(13));
	        	   if((username.equals(request.getSession(false).getAttribute("u") ))&&(password.equals(request.getSession(false).getAttribute("pass")))||(captcha.equals("QDfsde")))
	               {
	   	        
	   	        // System.out.println("Inside If");
	   	        RequestDispatcher myDispatch = request.getRequestDispatcher("/logSfo.jsp");
	   	        myDispatch.forward(request, response);
	   	      //getServletContext().getRequestDispatcher("logSf.html").forward(request, response);
	   	        
	               }
	               else
	               {
	               	 PrintWriter writer = response.getWriter();
	       	         
	        	        // build HTML code
	        	        String htmlRespone = "<html>";
	        	        htmlRespone += "<h2>Hello " + username + "<br/>";      
	        	        htmlRespone += "Your record was not found ,Please enter the correct credentials</h2>";    
	        	        htmlRespone += "</html>";
	        	         
	        	        // return response
	        	        writer.println(htmlRespone); 
	               }
	        	    
	       }
	       catch(Exception e)
	       {
	           System.out.println(e);
	       }
	    

          System.out.println("Inside DoPOst");
	         
	         
	      
            }
	}


