



import java.io.IOException;
import java.lang.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TwoPagetrue
 */
@WebServlet("/TwoPagetrue")
public class TwoPagetrue extends HttpServlet 
 {
	private static final long serialVersionUID = 1L;
       
   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
   {
	   String ac = request.getParameter("type");
	   
	   // enter lines to connect with db and evaluate the cash flow
	   //check if type is correct or not 
	  
	   if((ac.equals("Savings"))&&(request.getSession(false).getAttribute("SB_AccNo").equals("0")))
	   {
          Object a = request.getSession(false).getAttribute("SB_AccNo");
          Object b =request.getSession(false).getAttribute("SB_Acc_Amt");
		  RequestDispatcher myDispatch = request.getRequestDispatcher("Thirdpage.jsp");
		  request.getSession(false).setAttribute("type1","SB");
		  request.getSession(false).setAttribute("accType", a) ;
		  request.getSession(false).setAttribute("accName","SB_AccNo") ;// do tis for rest all types
		  request.getSession(false).setAttribute("accAmt",b) ;
	        myDispatch.forward(request, response);
		  
		    
	   }
	   else if((ac.equals("loan"))&&(request.getSession(false).getAttribute("Loan_AccNo").equals("0")))
	   {
	          Object a = request.getSession(false).getAttribute("Loan_AccNo");
	          Object b =request.getSession(false).getAttribute("Loan_Acc_Amt");
			  RequestDispatcher myDispatch = request.getRequestDispatcher("Thirdpage.jsp");
			  request.getSession(false).setAttribute("type1","LB");
			  request.getSession(false).setAttribute("accType", a) ;
			  request.getSession(false).setAttribute("accAmt",b) ;
		        myDispatch.forward(request, response);
			  
			    
		   }
	   else if((ac.equals("Current"))&&(request.getSession(false).getAttribute("CB_AccNo").equals("0")))
	   {
	          Object a = request.getSession(false).getAttribute("CB_AccNo");
	          Object b =request.getSession(false).getAttribute("CB_Acc_Amt");
			  RequestDispatcher myDispatch = request.getRequestDispatcher("Thirdpage.jsp");
			  request.getSession(false).setAttribute("type1","CB");
			  request.getSession(false).setAttribute("accType", a) ;
			  request.getSession(false).setAttribute("accAmt",b) ;
		        myDispatch.forward(request, response);
			  
			    
		   }
	   else if((ac.equals("FixedDeposit"))&&(request.getSession(false).getAttribute("FD_AccNo").equals("0")))
	   {
	          Object a = request.getSession(false).getAttribute("FD_AccNo");
	          Object b =request.getSession(false).getAttribute("FD_Acc_Amt");
			  RequestDispatcher myDispatch = request.getRequestDispatcher("Thirdpage.jsp");
			  request.getSession(false).setAttribute("type1","FB");
			  request.getSession(false).setAttribute("accType", a) ;
			  request.getSession(false).setAttribute("accAmt",b) ;
		        myDispatch.forward(request, response);
			  
			    
		   }
	   else
	   {
		   RequestDispatcher myDispatch = request.getRequestDispatcher("/ThirdpageF.jsp");
	        myDispatch.forward(request, response);
	   }
   

  }
 }


