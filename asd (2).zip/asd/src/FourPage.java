

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.Statement;

/**
 * Servlet implementation class FourPage
 */
@WebServlet("/FourPage")
public class FourPage extends HttpServlet
{
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    int Toacc= Integer.parseInt(request.getParameter("toacc"));
	    int Fromacc=(int) request.getSession(false).getAttribute("accType");
	   int cashPresent =(int) request.getSession(false).getAttribute("accAmt");
	request.getSession(false).getAttribute("accName") ;
		int amtDeduct = Integer.parseInt("amt");
		String atype= request.getParameter("atype") ;
		if(amtDeduct<cashPresent)
		{
			 try
		       {   System.out.println("Inside DoPOst2");
		       Integer NewcashA2 = null,UpdateCash = null;
		            Class.forName("com.mysql.jdbc.Driver").newInstance();
		           Connection myConn=DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","");
		           Statement stmt= (Statement) myConn.createStatement();
		           ResultSet rs=stmt.executeQuery("select"+atype+"_Amt from maintable where"+atype+" ="+Toacc);
		          while(rs.next())
		          {  NewcashA2= Integer.parseInt(rs.getString(1));
		             NewcashA2+=amtDeduct;
		             UpdateCash= cashPresent-amtDeduct;
		             
		           }
		          stmt.executeQuery("Update maintable set"+atype+"_Amt="+NewcashA2+"  where"+atype+" ="+Toacc);
		          stmt.executeQuery("Update maintable set"+request.getSession(false).getAttribute("accName") +"_Amt="+UpdateCash+"  where"+request.getSession(false).getAttribute("accName")+" ="+Fromacc);
		        	    
		       }
		       catch(Exception e)
		       {
		           System.out.println(e);
		       }
		    

			
		}
		else
		{
			response.sendRedirect("TransDeclined.jsp");
		}
	}

	
}

