package com.msd;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class mailgen
 */
@WebServlet("/mailgen")
public class mailgen extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
   		
  		try { 
       /* String to = (String) request.getSession(false).getAttribute("email");
        String from = "praveenavantgrade@gmail.com" ;
        String host = "smtp.gmail.com";
        Properties properties = System.getProperties();
        properties.setProperty("mail.user", "praveenavantgrade@gmail.com");
        properties.setProperty("mail.password", "Avantgrade7799");
        properties.setProperty("mail.smtp.host", host);
        properties.put("mail.smtp.port", "465"); */
  	    Object a= request.getParameter("sub") ;
  	  Object b= request.getParameter("amount") ;
        Random rand = new Random();
        int random = rand.nextInt(10000);
        request.getSession(false).setAttribute("OTP",random);
       FileWriter fileOut = new FileWriter("D:\\OTP.txt");
        fileOut.write("");
        fileOut.append("OTP is"+random);
        fileOut.close();
        request.getSession(false).setAttribute("fromacc",a);
        request.getSession(false).setAttribute("accamt",b);
         /*   Session session = Session.getDefaultInstance(properties);
           MimeMessage message = new MimeMessage(session);
           message.setFrom(new InternetAddress(from));
           message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
           message.setSubject("OTP initiated for the transcation!");
           message.setText("This is the otp "+ random );
           Transport.send(message);  */
           RequestDispatcher myDispatch = request.getRequestDispatcher("/Fourthpage.jsp");
  	        myDispatch.forward(request, response);
           
           
        } catch (Exception mex) {
        	 RequestDispatcher myDispatch = request.getRequestDispatcher("/logSfo.jsp");
   	        myDispatch.forward(request, response);
        }
		
	}


}
