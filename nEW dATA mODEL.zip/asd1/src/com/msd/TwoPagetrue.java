package com.msd;
import java.io.*;
import java.sql.Connection;
import java.sql.ResultSet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mchange.v2.c3p0.ComboPooledDataSource;

/**
 * Servlet implementation class TwoPagetrue
 */
@WebServlet("/TwoPagetrue")
public class TwoPagetrue extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	   {
		 try {
		   String ac = request.getParameter("type");
		   ComboPooledDataSource cpds = new ComboPooledDataSource();
	       int count =0,i=0;String id=request.getSession(false).getAttribute("customerid").toString() ;
			cpds.setDriverClass( "com.mysql.jdbc.Driver" );
		   cpds.setJdbcUrl( "jdbc:mysql://localhost:3306/bank" );
	       cpds.setUser("root");
	       cpds.setPassword("");
		   Connection myConn = cpds.getConnection();
		   String query = "SELECT * FROM customer table WHERE account_type = ? AND customerid = ?";
           java.sql.PreparedStatement pstmt =  myConn.prepareStatement(query) ;       
           pstmt.setString( 1, ac);
           pstmt.setString( 2, id);       
           ResultSet rs = pstmt.executeQuery( );
           while(rs.next())
           count++;
           rs.first();
           String[] accounts = new String[count];
           String[] accounts_amounts = new String[count];
           while(rs.next())
           accounts[i]=rs.getString(i++);
           i=0;
           while(count>i)
           {String query2 = "SELECT amount FROM account table WHERE account_id= ? ";
           java.sql.PreparedStatement pstmt2 =  myConn.prepareStatement(query) ;       
           pstmt2.setString( 1, accounts[i]);       
           ResultSet rs2 = pstmt.executeQuery( );
           accounts_amounts[i] =rs2.getString(i++);
           }
           PrintWriter writer = response.getWriter();
	        i=0; 
  	        String htmlRespone = "<html>";
  	        htmlRespone += "<h2>Hello " + request.getSession(false).getAttribute("name") + "<br/>";      
            htmlRespone += "<table><tr><td>Account Id</td>";
            htmlRespone += "<td>Amount Left</td>";
            htmlRespone += "<form action=\"${pageContext.request.contextPath}/mailgen\">";
            while(count>i)
            {
            	htmlRespone += "<tr><td>"+accounts[i]+"</td>";
                htmlRespone += "<td>"+accounts_amounts[i] +"</td>";
                htmlRespone += "<td>  <input type=\"hidden\" name=\"amount\" value="+accounts_amounts[i++]+"><button type=\"submit\" name=\"sub\" value="+accounts[i]+"> Initiate transcation</button></td></tr>";
            }
            htmlRespone += "</form>";
            htmlRespone += "</table>";
  	        htmlRespone += "</html>";
  	         
  	        // return response
  	        writer.println(htmlRespone); 
  	        
		   // enter lines to connect with db and evaluate the cash flow
		   //check if type is correct or not 
		    
		  /* if((ac.equals("Savings"))&&(!request.getSession(fa lse).getAttribute("SB_Acc").equals("0")))
		   {
	          Object a = request.getSession(false).getAttribute("SB_Acc");
	          Object b =request.getSession(false).getAttribute("SB_Acc_Amt");
			  RequestDispatcher myDispatch = request.getRequestDispatcher("/Thirdpage.jsp");
			  request.getSession(false).setAttribute("type1","SB");
			  request.getSession(false).setAttribute("accType", a) ;
			  request.getSession(false).setAttribute("accName","SB_Acc") ;// do tis for rest all types
			  request.getSession(false).setAttribute("accAmt",b) ;
		        myDispatch.forward(request, response);
			  
			    
		   }
		   else if((ac.equals("loan"))&&(!request.getSession(false).getAttribute("Loan_Acc").equals("0")))
		   {
		          Object a = request.getSession(false).getAttribute("Loan_Acc");
		          Object b =request.getSession(false).getAttribute("Loan_Acc_Amt");
				  RequestDispatcher myDispatch = request.getRequestDispatcher("/ThirdpageL.jsp");
				  request.getSession(false).setAttribute("type1","LB");
				  request.getSession(false).setAttribute("accType", a) ;
				  request.getSession(false).setAttribute("accName","Loan_Acc");
				  request.getSession(false).setAttribute("accAmt",b) ;
			        myDispatch.forward(request, response);
				  
				    
			   }
		   else if((ac.equals("Current"))&&(!request.getSession(false).getAttribute("CB_Acc").equals("0")))
		   {
		          Object a = request.getSession(false).getAttribute("CB_Acc");
		          Object b =request.getSession(false).getAttribute("CB_Acc_Amt");
				  RequestDispatcher myDispatch = request.getRequestDispatcher("/Thirdpage.jsp");
				  request.getSession(false).setAttribute("type1","CB");
				  request.getSession(false).setAttribute("accType", a) ;
				  request.getSession(false).setAttribute("accName","CB_Acc");
				  request.getSession(false).setAttribute("accAmt",b) ;
			        myDispatch.forward(request, response);
				  
				    
			   }
		   else if((ac.equals("FixedDeposit"))&&(!request.getSession(false).getAttribute("FD_Acc").equals("0")))
		   {
		          Object a = request.getSession(false).getAttribute("FD_Acc");
		          Object b =request.getSession(false).getAttribute("FD_Acc_Amt");
				 
				  request.getSession(false).setAttribute("type1","FB");
				  request.getSession(false).setAttribute("accType", a) ;
				  request.getSession(false).setAttribute("accAmt",b) ;
				  RequestDispatcher myDispatch = request.getRequestDispatcher("/ThirdpageL.jsp");
			        myDispatch.forward(request, response);
				  
				    
			   }
			   
		   else
		   {
			   RequestDispatcher myDispatch = request.getRequestDispatcher("/ThirdpageF.jsp");
		        myDispatch.forward(request, response);
		   }
	   */

	        
	   } 
		 catch(Exception e)
		 {
			// TODO Auto-generated catch block
			e.printStackTrace();
		  } //loads the jdbc driver
	    
     }
}
