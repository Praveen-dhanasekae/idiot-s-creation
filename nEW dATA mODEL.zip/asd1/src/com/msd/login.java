package com.msd;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.mysql.jdbc.PreparedStatement;



/**
 * Servlet implementation class login
 */
@WebServlet("/login")
public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{      System.out.println("Inside DoPOst 1");
		  final String username = request.getParameter("username");
	        String password = request.getParameter("password");
	       String captcha= request.getParameter("captcha");
	       
	       try
	       {  ComboPooledDataSource cpds = new ComboPooledDataSource();
	       cpds.setDriverClass( "com.mysql.jdbc.Driver" ); //loads the jdbc driver
	       cpds.setJdbcUrl( "jdbc:mysql://localhost:3306/bank" );
	       cpds.setUser("root");
	       cpds.setPassword("");

	      
	       cpds.setMinPoolSize(5);
	       cpds.setAcquireIncrement(5);
	       cpds.setMaxPoolSize(20);
	    	
	    	  /* javax.sql.DataSource source = new org.apache.commons.dbcp.BasicDataSource();
	    	   source.setDriverClassName("com.mysql.jdbc.Driver");
	    	   source.setUsername("username");
	    	   source.setPassword("password");
	    	   source.setUrl("jdbc:mysql://localhost:3306/myDatabase");
	    	   
	    	*/
	       
	          Connection myConn = cpds.getConnection();

	    	   System.out.println("Inside DoPOst2");
	           //loading the jdbc driver
	          //  Class.forName("com.mysql.jdbc.Driver").newInstance();
	          // Connection myConn=DriverManager.getConnection("jdbc:mysql://localhost:3306/bank","root","");
	           //Statement stmt= (Statement) myConn.createStatement();
	           //ResultSet rs=stmt.executeQuery("select * from maintable where u ='"+username+"'");
	         //  String custname = request.getParameter("customerName"); // This should REALLY be validated too
               // perform input validation to detect attacks
                  String query = "SELECT * FROM maintable WHERE name = ? ";
                  java.sql.PreparedStatement pstmt =  myConn.prepareStatement(query) ;       
                  pstmt.setString( 1, username); 
                  ResultSet rs = pstmt.executeQuery( );
	  
	           
	                        
	           
	        	while(rs.next())
	        	{
	               request.getSession(false).setAttribute("sno",rs.getString(1));
	        	   request.getSession(false).setAttribute("name",rs.getString(2));
	        	   request.getSession(false).setAttribute("mail" ,rs.getString(3));
	        	   request.getSession(false).setAttribute("password",rs.getString(4));
	        	   request.getSession(false).setAttribute("checkin" ,rs.getString(5));
	        	   request.getSession(false).setAttribute("customer_id" ,rs.getString(6));
	        	   request.getSession(false).setAttribute("aadhar" ,rs.getString(7));
	        	}
	        	   if((username.equals(request.getSession(false).getAttribute("name") ))&&(password.equals(request.getSession(false).getAttribute("password")))||(captcha.equals("QDfsde")))
	               {
	   	        
	   	        // System.out.println("Inside If");
	   	        RequestDispatcher myDispatch = request.getRequestDispatcher("/logSfo.jsp");
	   	        myDispatch.forward(request, response);
	   	      //getServletContext().getRequestDispatcher("logSf.html").forward(request, response);
	   	        
	               }
	               else
	               {
	               	 PrintWriter writer = response.getWriter();
	       	         
	        	        // build HTML code
	        	        String htmlRespone = "<html>";
	        	        htmlRespone += "<h2>Hello " + username + "<br/>";      
	        	        htmlRespone += "Your record was not found ,Please enter the correct credentials</h2>";    
	        	        htmlRespone += "</html>";
	        	         
	        	        // return response
	        	        writer.println(htmlRespone); 
	               }
	        	    
	       }
	       catch(Exception e)
	       {
	    	   PrintWriter writer = response.getWriter();
     	         
   	        String htmlRespone = "<html>";
   	        htmlRespone += "<h2>Hello " + username + "<br/>";      
   	        htmlRespone += "An unexpected error was caught, <a href=\"LoginAuth.jsp\">Click here to login again</a> </h2>";    
   	        htmlRespone += "</html>";
   	         
   	        // return response
   	        writer.println(htmlRespone); 
   	        
	       }
	    

          System.out.println("Inside DoPOst");
	         
	         
	      
            }
}
