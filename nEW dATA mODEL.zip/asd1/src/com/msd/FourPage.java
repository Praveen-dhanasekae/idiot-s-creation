package com.msd;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.mysql.jdbc.Statement;

/**
 * Servlet implementation class FourPage
 */
@WebServlet("/FourPage")
public class FourPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		ComboPooledDataSource cpds = new ComboPooledDataSource();
	       //int count =0,i=0;String id=request.getSession(false).getAttribute("customerid").toString() ;
			cpds.setDriverClass( "com.mysql.jdbc.Driver" );
		   cpds.setJdbcUrl( "jdbc:mysql://localhost:3306/bank" );
	       cpds.setUser("root");
	       cpds.setPassword("");
		   Connection myConn = cpds.getConnection();
		   
	    int Toacc= Integer.parseInt(request.getParameter("toacc"));//ACCOUNT NUMBER TO TRANSFER
	    int Fromacc=Integer.parseInt( (String) request.getSession(false).getAttribute("fromacc")); //ACCOUNT NUMBER FROM TRANSFER
	   int cashPresent =Integer.parseInt((String) request.getSession(false).getAttribute("accamt")); // -->CASH inside
	//request.getSession(false).getAttribute("accName") ;
	   String query = "SELECT Amount FROM account table WHERE account_id = ? ";
	   java.sql.PreparedStatement pstmt = myConn.prepareStatement( query );
       pstmt.setString( 1, (String) request.getSession(false).getAttribute("fromacc")); 
       ResultSet results = pstmt.executeQuery( );
		int amtDeduct = Integer.parseInt(request.getParameter("amt"));
		String atype= request.getParameter("atype") ;
		Integer OTP = (Integer)request.getSession(false).getAttribute("OTP");
		int otp = Integer.parseInt(request.getParameter("OTPP"));
		int amtReal= Integer.parseInt((String)results.getString(1));
		if(amtReal>=cashPresent)
		{	cashPresent=amtReal ;
		if(OTP ==otp)
		{
		    if(amtDeduct<cashPresent)
		  {
			 try
		       {   System.out.println("Inside DoPOst2");
		       Integer NewcashA2 = null,UpdateCash = null;
		           
		           // Use prepared statement <- <-  
		           /* String custname = request.getParameter("customerName"); // This should REALLY be validated too
                     // perform input validation to detect attacks
                        String query = "SELECT account_balance FROM user_data WHERE user_name = ? ";
 
                        PreparedStatement pstmt = connection.prepareStatement( query );
                        pstmt.setString( 1, custname); 
                        ResultSet results = pstmt.executeQuery( );
		            * 
		            * 
		            */
		       String query1 ="select * from account table where account_id ="+Toacc;
		       java.sql.PreparedStatement pstmt1 = myConn.prepareStatement( query1 );
		       pstmt.setString( 1, (String) request.getSession(false).getAttribute("fromacc")); 
		       ResultSet rs = pstmt.executeQuery( );
		           
		          while(rs.next())
		          {  NewcashA2= Integer.parseInt(rs.getString(3));
		             NewcashA2+=amtDeduct;
		             UpdateCash= cashPresent-amtDeduct;
		             
		           }
		          stmt.executeUpdate("Update maintable set "+atype+"_Amt="+NewcashA2+"  where "+atype+" ="+Toacc);
		          stmt.executeUpdate("Update maintable set "+request.getSession(false).getAttribute("accName") +"_Amt="+UpdateCash+"  where "+request.getSession(false).getAttribute("accName")+" ="+Fromacc);
		          if(request.getSession(false).getAttribute("accName").equals("SB_Acc"))
		          { if(UpdateCash>=500)  
		            { rs= stmt.executeQuery("select "+request.getSession(false).getAttribute("accName")+" from table2 where Aadhar ="+request.getSession(false).getAttribute("Aadhar"));
		            rs.next(); 
		            int ne=Integer.parseInt( (String) rs.getString(1));
		            ne+=1;System.out.println(ne);
		               stmt.executeUpdate("Update table2 set "+request.getSession(false).getAttribute("accName") +"="+ ne +"  where "+request.getSession(false).getAttribute("accName")+" ="+Fromacc);
		            } 		
		          if(UpdateCash<500)  
		            { rs= stmt.executeQuery("select "+request.getSession(false).getAttribute("accName")+"_low from table2 where Aadhar ="+request.getSession(false).getAttribute("Aadhar"));
		            rs.next(); 
		            int ne=Integer.parseInt( (String) rs.getString(1));
		            ne+=1;System.out.println(ne);
		               stmt.executeUpdate("Update table2 set "+request.getSession(false).getAttribute("accName") +"_low ="+ ne +"  where Aadhar ="+request.getSession(false).getAttribute("Aadhar"));

		            }
		          
		           }
		          if(request.getSession(false).getAttribute("accName").equals("CB_Acc"))
		          { if(UpdateCash>=2000)  
		            { rs= stmt.executeQuery("select "+request.getSession(false).getAttribute("accName")+" from table2 where Aadhar ="+request.getSession(false).getAttribute("Aadhar"));
		            rs.next();  
		            int ne=Integer.parseInt( (String) rs.getString(1));
		            ne+=1;System.out.println(ne);
		               stmt.executeUpdate("Update table2 set "+request.getSession(false).getAttribute("accName") +"="+ ne +"  where Aadhar ="+request.getSession(false).getAttribute("Aadhar"));
		            } 		
		          if(UpdateCash<2000)  
		            { rs= stmt.executeQuery("select "+request.getSession(false).getAttribute("accName")+"_low from table2 where Aadhar ="+request.getSession(false).getAttribute("Aadhar"));
		            rs.next();  
		            int ne=Integer.parseInt( (String) rs.getString(1));
		            ne+=1;System.out.println(ne);
		               stmt.executeUpdate("Update table2 set "+request.getSession(false).getAttribute("accName") +"_low ="+ ne +"  where Aadhar ="+request.getSession(false).getAttribute("Aadhar"));
		            } 		
		          
		          
		           }
		           //Runtime.getRuntime().exec("python pyScript.py");
		          RequestDispatcher myDispatch = request.getRequestDispatcher("/OTPSuccess.jsp");
		   	        myDispatch.forward(request, response);
		       }
		       catch(Exception e)
		       {
		    	   PrintWriter writer = response.getWriter();
	     	         
		   	        String htmlRespone = "<html>";
		   	        htmlRespone += "<h2>Hello " + request.getSession(false).getAttribute("u") + "<br/>";      
		   	        htmlRespone += "The transcation was unable to process, <a href=\"Thirdpage.jsp\">Click here to enter amount again</a> </h2>";    
		   	        htmlRespone += "</html>";
		   	         
		   	        // return response
		   	        writer.println(htmlRespone); 
		       }
			 
		    

			
		   }
		  else
		  {
			response.sendRedirect("TransDeclined.jsp");
		  }
	}
	
	else 
	{
		response.sendRedirect("OTPFailed.jsp");

	}
	
	}
   else
   {
	   PrintWriter writer = response.getWriter();
	         
       
       String htmlRespone = "<html>";
       htmlRespone += "<h2>Hello " + request.getSession(false).getAttribute("name") + "<br/>";      
       htmlRespone += "Your record was changed ,Please <a href=\"LoginAuth.jsp\">login again</a></h2>";    
       htmlRespone += "</html>";
        
      
       writer.println(htmlRespone);  
   
   }
   }

}
